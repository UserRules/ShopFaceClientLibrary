package org.jboss.resteasy.core;

import org.jboss.resteasy.util.CaseInsensitiveMap;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public class Headers<V> extends CaseInsensitiveMap<V>
{
}
