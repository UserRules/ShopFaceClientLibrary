package org.jboss.resteasy.spi;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public interface ProviderFactoryDelegate
{
   ResteasyProviderFactory getDelegate();
}
