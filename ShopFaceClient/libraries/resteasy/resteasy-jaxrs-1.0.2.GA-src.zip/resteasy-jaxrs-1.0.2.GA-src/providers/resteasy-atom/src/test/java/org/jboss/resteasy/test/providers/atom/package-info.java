//@XmlSchema(namespace = "http://jboss.org/Customer",
//        attributeFormDefault = XmlNsForm.QUALIFIED,
//        elementFormDefault = XmlNsForm.QUALIFIED)
package org.jboss.resteasy.test.providers.atom;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;

