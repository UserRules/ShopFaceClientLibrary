package org.jboss.resteasy.test.providers.jaxb.seealso;

import javax.xml.bind.annotation.XmlSeeAlso;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
@XmlSeeAlso(RealFoo.class)
public class BaseFoo
{
}
