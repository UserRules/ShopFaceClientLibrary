package org.jboss.resteasy.plugins.stats;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
@XmlRootElement(name = "put")
public class PutResourceMethod extends ResourceMethodEntry
{
}