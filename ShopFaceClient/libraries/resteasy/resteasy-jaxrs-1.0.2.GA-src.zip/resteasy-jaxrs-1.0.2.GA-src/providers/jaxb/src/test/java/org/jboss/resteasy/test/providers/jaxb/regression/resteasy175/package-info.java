/**
 * RESTful Web Service f&uuml;r Kunden mittels JAX-RS und JAXB.
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://hska.de/kundenverwaltung") package org.jboss.resteasy.test.providers.jaxb.regression.resteasy175;
