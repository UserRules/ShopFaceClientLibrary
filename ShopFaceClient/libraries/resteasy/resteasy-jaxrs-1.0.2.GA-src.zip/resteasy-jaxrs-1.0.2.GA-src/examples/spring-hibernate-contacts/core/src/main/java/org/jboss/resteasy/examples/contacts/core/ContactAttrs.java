package org.jboss.resteasy.examples.contacts.core;


/**
 * @author <a href="mailto:obrand@yahoo.com">Olivier Brand</a>
 * Jun 28, 2008
 * 
 */
public enum ContactAttrs
{
    name, telephone, email, id;
}
