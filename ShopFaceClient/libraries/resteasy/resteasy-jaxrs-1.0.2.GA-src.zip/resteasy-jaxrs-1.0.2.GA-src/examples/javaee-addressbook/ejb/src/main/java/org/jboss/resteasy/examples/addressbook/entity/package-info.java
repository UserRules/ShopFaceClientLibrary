@javax.xml.bind.annotation.XmlSchema (
      xmlns = { 
        @javax.xml.bind.annotation.XmlNs(
        		prefix = "re", 
                namespaceURI="http://www.jboss.org/RESTEasy/examples/addressbook")})
package org.jboss.resteasy.examples.addressbook.entity;