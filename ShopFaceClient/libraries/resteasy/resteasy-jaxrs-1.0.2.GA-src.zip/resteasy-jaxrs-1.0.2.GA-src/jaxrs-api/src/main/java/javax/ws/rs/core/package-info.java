/**
 * Low-level interfaces and annotations used to create RESTful service
 * resources.
 */
package javax.ws.rs.core;